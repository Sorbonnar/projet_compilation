// Expected output:
// Even
// Odd
// Even
//

void main() {
    int i = 0;
    while (i < 3) {
        if (i % 2 == 0) {
            print("Even\n");
        }
        else {
            print("Odd\n");
        }
        i = i + 1;
    }
}

// Expected output:
// Total: 30
//

int a = 5;
int b = 10;

void main() {
    int c = 15;
    int sum = a + b + c;
    print("Total: ", sum, "\n");
}

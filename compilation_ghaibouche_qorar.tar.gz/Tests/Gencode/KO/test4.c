// No expected output
void main() {
    int c = 2 % 0;
}

// No expected output
void main() {
    int a = 5;
    int b = 0;

    int c = a / b;
}

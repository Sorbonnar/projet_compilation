// No expected output
void main() {
    int a;
    int b = a + 10;

    print("b: ", b, "\n");
}

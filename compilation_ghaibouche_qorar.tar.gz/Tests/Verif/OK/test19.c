void main() {
    int a = 8, b = 9, c = 10;
    int d = a * b * c * a * b * c * a * b * c * a;
    print(d);
    print("\n");
}
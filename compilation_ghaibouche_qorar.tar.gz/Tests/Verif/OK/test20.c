void main() {
    while (true) {
    }
}

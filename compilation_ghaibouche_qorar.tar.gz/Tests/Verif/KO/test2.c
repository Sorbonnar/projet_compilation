// 8

void main() {
    do {
        int a = 1;
        int b = 1;
        int c = a + b;
    } while (1);
}
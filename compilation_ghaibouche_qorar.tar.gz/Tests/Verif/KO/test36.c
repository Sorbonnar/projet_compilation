// 4

void main() {
   int a = b + 1;
   int b = 2;
}

// 4

void main() {
    bool a = 1;
}

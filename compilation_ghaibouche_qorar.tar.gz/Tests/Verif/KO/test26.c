// 7

void main(){
    int t=5;
    bool a = true;
    bool b = true;
    if(a > b){};
}
// 4

void main() {
    int a = true;
}

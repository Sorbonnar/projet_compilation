// 6

void main(){
    int z=5;
    bool a = true;
    a=~a;
}
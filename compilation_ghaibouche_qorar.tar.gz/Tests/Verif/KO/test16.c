// 5

int b = 1;
int c = 1;
int d = b + c;
void main() {
}

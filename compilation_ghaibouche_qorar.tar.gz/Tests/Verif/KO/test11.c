// 6

void main(){
    int i;
    bool a =true;
    a= a%i;
}
// 4
void main() {
    int a = 1;
    while(a) {
        print("HelloWorld");
    }
}
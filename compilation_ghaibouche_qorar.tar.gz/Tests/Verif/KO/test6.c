// 5

void main(){
    bool z=false;
    z =z^z;
}
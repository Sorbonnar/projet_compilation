// 3

void maine() {
	a = 10;
}

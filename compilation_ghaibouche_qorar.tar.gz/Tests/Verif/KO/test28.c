// 6

int z=5;
void main(){

    bool a = 1;
}
// 6

void main() {
   int a = 0x22;
   bool b = false;
   bool c = a + b;
   
}

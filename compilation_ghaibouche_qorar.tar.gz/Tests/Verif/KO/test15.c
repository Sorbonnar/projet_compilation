// 5

void main() {
    int a;
    if (2) {
        print(a);
    }
}

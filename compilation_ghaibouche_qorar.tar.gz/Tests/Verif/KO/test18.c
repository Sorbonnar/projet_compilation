// 7

void main() {
    if (true) {
        int a = 5;
    }
    print(a);
}
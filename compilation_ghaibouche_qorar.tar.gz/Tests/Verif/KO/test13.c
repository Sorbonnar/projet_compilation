// 6

void main() {
    bool a = true;
    if (!a) {
        print(b);
    }
}
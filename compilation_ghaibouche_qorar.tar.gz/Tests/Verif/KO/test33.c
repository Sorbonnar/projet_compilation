// 6

void main(){
    bool a = true;
    int e = 8;
    bool r = a / e;
}
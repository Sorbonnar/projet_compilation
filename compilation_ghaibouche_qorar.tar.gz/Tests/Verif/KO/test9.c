// 4

void main(){
     if(5){
         int a;
     }else{
         int b;


     }

}
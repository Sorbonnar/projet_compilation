// 5

void main() {
   int a = 1;
   int a = 0;
}

// 6

void main(){
    int t=5;
    bool a = true;
    a<<1;
}
// 4

void main() {
    void a;
}
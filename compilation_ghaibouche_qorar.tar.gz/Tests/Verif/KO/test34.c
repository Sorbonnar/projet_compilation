// 5

void main() {
    int b = 2;
    bool b = true;
}
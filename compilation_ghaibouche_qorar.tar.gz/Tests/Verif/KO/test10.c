// 3

int maine(){

     int i =0;
     print("i",i);

}
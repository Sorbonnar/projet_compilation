// 4

int a = 1;
int b = a + 1;
void main() {
}
// 6

void main() {
    int a = 1;
    int b = 1;
    bool c = a && b;
}

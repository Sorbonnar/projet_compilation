void main() {
	bool a = true;
	int b = ~a;
}
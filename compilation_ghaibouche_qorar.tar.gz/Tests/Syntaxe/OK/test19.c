void main() {
	a = 10;
}

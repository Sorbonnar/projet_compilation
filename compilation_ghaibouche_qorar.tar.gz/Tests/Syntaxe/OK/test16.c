void main() {
    int a = true;
}

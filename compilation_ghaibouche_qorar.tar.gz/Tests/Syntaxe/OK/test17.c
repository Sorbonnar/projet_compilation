void main() {
    int b = 2;
    if (b) {
        int a = 5;
    }
    print(a);
}

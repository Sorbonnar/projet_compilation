int a = 2;
int b = a + 1;
void main() {
}

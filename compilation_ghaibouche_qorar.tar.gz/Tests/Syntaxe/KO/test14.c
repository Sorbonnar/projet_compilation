// 3

void main[] {
    a;
}
// 4

void main() {
    printf("a");
}
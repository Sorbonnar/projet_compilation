// 4

void main() {
   int a = 0xFFFFFFFFF;
}
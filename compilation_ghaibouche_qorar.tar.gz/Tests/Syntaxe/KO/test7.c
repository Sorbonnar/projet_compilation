// 4

void main() {
    int $c = 0;
}
// 4

void main() {
    for (c = 0; c < b; i++) {
        a;
    }
}
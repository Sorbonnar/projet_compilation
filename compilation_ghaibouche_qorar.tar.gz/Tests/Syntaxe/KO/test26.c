// 4

void main() {
    while 1 {
        a;
    }    
}
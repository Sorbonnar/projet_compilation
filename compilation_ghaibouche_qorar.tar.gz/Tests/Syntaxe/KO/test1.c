// 4

void main() {
    int a = 1 b = 100;
}
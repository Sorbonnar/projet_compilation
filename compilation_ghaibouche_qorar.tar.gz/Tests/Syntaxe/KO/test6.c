// 4

void main() {
    int 1c = 0;
}
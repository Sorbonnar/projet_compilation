// 3

main() {
    a;
}
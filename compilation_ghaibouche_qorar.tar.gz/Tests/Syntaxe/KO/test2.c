// 4

void main() {
    int a = a * {};
}
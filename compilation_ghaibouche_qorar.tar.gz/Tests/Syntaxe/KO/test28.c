// 7

void main() {
    do {
        a;
    }
    while 1;
}
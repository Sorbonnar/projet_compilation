// 4

void main() {
    a = b ||;
}
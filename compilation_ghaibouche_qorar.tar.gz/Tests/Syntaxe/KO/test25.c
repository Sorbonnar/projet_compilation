// 4

void main() {
    if c {
        a;
    }
}